# Online_Voting_System
This Platform is online voting platform, that platform allows groups to securely conduct votes and elections.
<br>
Author-Arpita More
